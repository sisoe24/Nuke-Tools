# __projectSlug__ README

## Features

- Some nice features

## Installation

To install this plugin ...

## Usage

To use this plugin ...

## Known Issues

The plugin does not support ...

## Compatibility

Nuke Versions: 11, 12, 13

## Screenshots

...
