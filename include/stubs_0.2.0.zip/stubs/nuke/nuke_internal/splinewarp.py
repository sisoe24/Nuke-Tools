"""The Python interface for used by SplineWarp

Use help('_splinewarp') to get detailed help on the classes exposed here.
"""

import _splinewarp
from _splinewarp import SplineKnob

from .curveknob import *
