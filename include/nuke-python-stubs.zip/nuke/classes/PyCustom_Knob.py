from typing import *
from numbers import Number

import nuke

from . import *


class PyCustom_Knob(Script_Knob):
    """
    PyCustom_Knob
    """

    def __hash__(self, ):
        """
        Return hash(self).
        """
        return None

    def __init__(self,  *args, **kwargs):
        """
        Initialize self.  See help(type(self)) for accurate signature.
        """
        return None

    def __new__(self, *args, **kwargs):
        """
        Create and return a new object.  See help(type) for accurate signature.
        """
        return None

    def getObject(self, *args, **kwargs):
        """
        Returns the custom knob object as created in the by the 'command' argument to the PyCuston_Knob constructor.
        """
        return None
