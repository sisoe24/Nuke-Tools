from typing import *
from numbers import Number

import nuke

from . import *


class RunInMainThread(object):
    """
    RunInMainThread
    """

    def __hash__(self, ):
        """
        Return hash(self).
        """
        return None

    def request(self, *args, **kwargs):
        """

        """
        return None

    def result(self, *args, **kwargs):
        """

        """
        return None

    def __init__(self,  *args, **kwargs):
        """
        Initialize self.  See help(type(self)) for accurate signature.
        """
        return None
