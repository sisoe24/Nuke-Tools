import typing
from typing import *
from numbers import Number

import ui
import core
import PySide2
from PySide2.QtCore import Signal
from PySide2.QtWidgets import *

from . import *


class ViewerCursor(Object):
    """

    """

    def __init__(self,  *args, **kwargs):
        """
        Initialize self.  See help(type(self)) for accurate signature.
        """
        return None

    def __new__(self, *args, **kwargs):
        """
        Create and return a new object.  See help(type) for accurate signature.
        """
        return None

    def __copy__(self,) -> None:
        """

        """
        return None

    @property
    def pos(self) -> Any:
        """

        """
        return None

    @property
    def color(self) -> Any:
        """

        """
        return None

    @property
    def label(self) -> Any:
        """

        """
        return None
